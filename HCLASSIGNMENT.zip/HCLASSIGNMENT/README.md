
This repository contains the content of the HCL Banking assignment
